package hu.ait.minesweeper.view


import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import hu.ait.minesweeper.MainActivity
import hu.ait.minesweeper.R
import hu.ait.minesweeper.model.BoardModel

class BoardView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {

    lateinit var paintBackground: Paint

    var gameOver = false

    var bitmapButton: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperbutton)
    var bitmapMine: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweepermine)
    var bitmapFlag: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperflag)
    var bitmapZero: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperzero)
    var bitmapOne: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperone)
    var bitmapTwo: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweepertwo)
    var bitmapThree: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperthree)
    var bitmapFour: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.minesweeperfour)

    init {
        paintBackground = Paint()
        paintBackground.setColor(Color.parseColor("#04123A"))
        paintBackground.style = Paint.Style.FILL
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        bitmapButton = Bitmap.createScaledBitmap(
            bitmapButton, width / 5, height / 5, false
        )

        bitmapMine = Bitmap.createScaledBitmap(
            bitmapMine, width / 5, height / 5, false
        )

        bitmapFlag = Bitmap.createScaledBitmap(
            bitmapFlag, width / 5, height / 5, false
        )

        bitmapZero = Bitmap.createScaledBitmap(
            bitmapZero, width / 5, height / 5, false
        )

        bitmapOne = Bitmap.createScaledBitmap(
            bitmapOne, width / 5, height / 5, false
        )

        bitmapTwo = Bitmap.createScaledBitmap(
            bitmapTwo, width / 5, height / 5, false
        )

        bitmapThree = Bitmap.createScaledBitmap(
            bitmapThree, width / 5, height / 5, false
        )

        bitmapFour = Bitmap.createScaledBitmap(
            bitmapFour, width / 5, height / 5, false
        )

    }


    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintBackground)

        drawCells(canvas)

    }


    private fun drawCells(canvas: Canvas) {
        for (i in 0..4) {
            for (j in 0..4) {
                if (BoardModel.getFieldContent(i, j).wasClicked) {
                    if (BoardModel.getFieldContent(i, j).type == 1) {
                        canvas.drawBitmap(
                            bitmapMine, (i * width / 5).toFloat(),
                            (j * height / 5).toFloat(), null)
                    } else {
                        if (BoardModel.getFieldContent(i, j).minesAround.toString() == "0")
                            canvas.drawBitmap(
                                bitmapZero, (i * width / 5).toFloat(),
                                (j * height / 5).toFloat(), null
                            )
                        if (BoardModel.getFieldContent(i, j).minesAround.toString() == "1")
                            canvas.drawBitmap(
                            bitmapOne, (i * width / 5).toFloat(),
                            (j * height / 5).toFloat(), null
                            )
                        if (BoardModel.getFieldContent(i, j).minesAround.toString() == "2")
                            canvas.drawBitmap(
                                bitmapTwo, (i * width / 5).toFloat(),
                                (j * height / 5).toFloat(), null
                            )
                        if (BoardModel.getFieldContent(i, j).minesAround.toString() == "3")
                            canvas.drawBitmap(
                                bitmapThree, (i * width / 5).toFloat(),
                                (j * height / 5).toFloat(), null
                            )
                        if (BoardModel.getFieldContent(i, j).minesAround.toString() == "4")
                            canvas.drawBitmap(
                                bitmapFour, (i * width / 5).toFloat(),
                                (j * height / 5).toFloat(), null
                            )
                    }
                } else {
                    if (BoardModel.getFieldContent(i, j).isFlagged) {
                        canvas.drawBitmap(
                            bitmapFlag, (i * width / 5).toFloat(),
                            (j * height / 5).toFloat(), null
                        )
                    } else {
                        canvas.drawBitmap(
                        bitmapButton, (i * width / 5).toFloat(),
                        (j * height / 5).toFloat(), null
                        )
                    }
                }
            }
        }
    }


    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!gameOver && event.action == MotionEvent.ACTION_DOWN ){
            val tX = event.x.toInt() / (width / 5)
            val tY = event.y.toInt() / (height / 5)
            if (!(context as MainActivity).isFlagModeOn() && !BoardModel.getFieldContent(tX, tY).isFlagged) {
                if (BoardModel.getFieldContent(tX, tY).type == 1) {
                    loser()
                } else {
                    BoardModel.getFieldContent(tX, tY).wasClicked = true
                }
            } else if ((context as MainActivity).isFlagModeOn() && !BoardModel.getFieldContent(tX, tY).isFlagged) {
                if (BoardModel.getFieldContent(tX, tY).wasClicked == false && BoardModel.getFieldContent(tX, tY).type == 0) {
                    loser()
                } else {
                    BoardModel.getFieldContent(tX, tY).isFlagged = true
                }
            }
            winner()
            invalidate()
        }
        return true
    }


    fun loser() {
        (context as MainActivity).showMessage(context.getString(R.string.youLost))
        BoardModel.loser()
        gameOver = true
        (context as MainActivity).binding.imageView.setImageResource(R.drawable.minesweepernotchill)
    }


    fun winner() {
        if (BoardModel.checkWinner()){
            (context as MainActivity).showMessage(context.getString(R.string.youWon))
            gameOver = true
        }
    }


    fun resetGame() {
        gameOver = false
        (context as MainActivity).binding.cbFlag.isChecked = false
        BoardModel.resetModel()
        (context as MainActivity).showMessage(context.getString(R.string.defaultTvData))
        (context as MainActivity).binding.imageView.setImageResource(R.drawable.minesweeperchill)
        invalidate()
    }

}

