package hu.ait.minesweeper.model

import android.util.Log
import hu.ait.minesweeper.MainActivity
import kotlin.random.Random

object BoardModel {
    data class Field(var type: Int,
                     var minesAround: Int,
                     var isFlagged: Boolean,
                     var wasClicked: Boolean)

    val random = Random.Default

    val fieldMatrix: Array<Array<Field>> = arrayOf(
        arrayOf(Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false)),
        arrayOf(Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false)),
        arrayOf(Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false)),
        arrayOf(Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false)),
        arrayOf(Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false),
            Field(0, 0, false, false)))

    // Select 5 random mines from the fieldMatrix

    fun resetModel() {
        val mines: MutableSet<Pair<Int, Int>> = mutableSetOf()
        for (i in 0..4) {
            for (j in 0..4) {
                fieldMatrix[i][j] = Field(0, 0, false, false)
            }
        }

        while (mines.size < 4) {
            val randomRow = random.nextInt(5)
            val randomCol = random.nextInt(5)
            if (Pair(randomRow, randomCol) !in mines) {
                mines.add(Pair(randomRow, randomCol))
            }
        }

        mines.forEach { mine ->
            fieldMatrix[mine.first][mine.second].type = 1
        }

        for (i in 0..4) {
            for (j in 0..4){
                if (fieldMatrix[i][j].type != 1) {
                    val adjRows = mutableListOf<Int>()
                    val adjCols = mutableListOf<Int>()
                    adjRows.add(i)
                    adjCols.add(j)
                    if (i != 4) adjRows.add(i+1)
                    if (i != 0) adjRows.add(i-1)
                    if (j != 4) adjCols.add(j+1)
                    if (j != 0) adjCols.add(j-1)
                    Log.d("ADJ", "${i}, ${j}, ${adjRows}, ${adjCols}")
                    for (x in adjRows) {
                        for (y in adjCols) {
                            fieldMatrix[i][j].minesAround += fieldMatrix[x][y].type
                        }
                    }
                }
            }
        }
    }

    fun getFieldContent(x: Int, y: Int) = fieldMatrix[x][y]

    fun loser() {
        for (i in 0..4) {
            for (j in 0..4) {
                if (fieldMatrix[i][j].type == 1) {
                    fieldMatrix[i][j].wasClicked = true
                }
            }
        }
    }

    fun checkWinner(): Boolean {
        var minesFlagged = 0
        var nonMinesClicked = 0
        for (i in 0..4) {
            for (j in 0..4) {
                if (fieldMatrix[i][j].type == 1 &&fieldMatrix[i][j].isFlagged){
                    minesFlagged +=1
                }
                if (fieldMatrix[i][j].type == 0 && fieldMatrix[i][j].wasClicked){
                    nonMinesClicked +=1
                }
            }
        }
        if (minesFlagged == 4 || nonMinesClicked == 21 ) {
            winner()
            return true
        }
        return false
    }

    fun winner() {
            for (i in 0..4) {
                for (j in 0..4) {
                    if (fieldMatrix[i][j].type == 1 ){
                        fieldMatrix[i][j].isFlagged = true
                    } else {
                        fieldMatrix[i][j].wasClicked = true
                    }
                }
            }
        }
}